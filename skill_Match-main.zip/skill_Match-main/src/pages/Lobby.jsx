import React, { useState } from 'react';
import './Lobby.css';

const Lobby = () => {
  const [activeMenu, setActiveMenu] = useState('Lobi');
  const [activeFilter, setActiveFilter] = useState('Tümü');

  // Lobi için Sahte (Mock) Veriler - Senin attığın fotoğraftaki yapıya uygun
  const matchCards = [
    { id: 1, player: "Hayrani ER", rank: "Altın 3", game: "Valorant", target: "En az 10 Kill", bet: 100, gameClass: "valorant" },
    { id: 2, player: "Kaan Y.", rank: "Platin 1", game: "LoL", target: "Maçı Kazan", bet: 250, gameClass: "lol" },
    { id: 3, player: "Ahmet Efe MAT", rank: "Elmas", game: "CS:GO", target: "En az 20 Kill", bet: 500, gameClass: "csgo" },
    { id: 4, player: "Berkay D.", rank: "Gümüş 2", game: "Valorant", target: "MVP Ol", bet: 50, gameClass: "valorant" },
    { id: 5, player: "Onur K.", rank: "Şampiyon", game: "LoL", target: "En az 15 Asist", bet: 150, gameClass: "lol" },
    { id: 6, player: "Hayrani ER", rank: "Altın 3", game: "CS:GO", target: "1v2 Clutch At", bet: 300, gameClass: "csgo" },
  ];

  // Filtreleme Mantığı
  const filteredCards = activeFilter === 'Tümü' 
    ? matchCards 
    : matchCards.filter(card => card.game === activeFilter);

  return (
    <div className="lobby-container">
      {/* Arka plan parlamaları */}
      <div className="lobby-glow-1"></div>
      <div className="lobby-glow-2"></div>

      {/* --- SOL MENÜ (SIDEBAR) --- */}
      <aside className="sidebar">
        <div className="sidebar-logo">
          <div className="sidebar-logo-icon">S</div>
          <div className="sidebar-logo-text">Skill<span>Match</span></div>
        </div>

        <nav className="nav-menu">
          {['Lobi', 'Cüzdan', 'Geçmiş Maçlar', 'Ayarlar'].map((menu) => (
            <div 
              key={menu} 
              onClick={() => setActiveMenu(menu)}
              className={`nav-item ${activeMenu === menu ? 'active' : ''}`}
            >
              {/* Basit ikonlar yerine SVG simülasyonu koyabiliriz, şimdilik yazı */}
              <span>{menu}</span>
            </div>
          ))}
        </nav>
      </aside>

      {/* --- ANA İÇERİK --- */}
      <main className="main-content">
        
        {/* Üst Bar (Header) */}
        <header className="header">
          <h1 className="page-title">Live Lobby</h1>
          
          <div className="user-controls">
            <div className="credit-box">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2"/></svg>
              500 Kredi
            </div>
            
            <div className="profile-box">
              <div className="profile-details" style={{textAlign: 'right'}}>
                <div className="profile-name">Ahmet Efe MAT</div>
                <div style={{fontSize: '0.75rem', color: '#9CA3AF'}}>Çevrimiçi</div>
              </div>
              <img src="https://i.pravatar.cc/150?img=11" alt="Profile" className="profile-avatar" />
            </div>

            <button className="add-btn" title="Yeni İddia Oluştur">+</button>
          </div>
        </header>

        {/* Lobiler (İddia Kartları) */}
        {activeMenu === 'Lobi' && (
          <div className="lobby-section">
            
            {/* Oyun Filtreleri */}
            <div className="filters">
              {['Tümü', 'LoL', 'Valorant', 'CS:GO'].map(game => (
                <button 
                  key={game}
                  onClick={() => setActiveFilter(game)}
                  className={`filter-btn ${activeFilter === game ? 'active' : ''}`}
                >
                  {game}
                </button>
              ))}
            </div>

            {/* Kart Grid'i */}
            <div className="cards-grid">
              {filteredCards.map(card => (
                <div key={card.id} className="match-card">
                  <div className="card-header">
                    <div className="player-info">
                      <img src={`https://i.pravatar.cc/150?u=${card.id}`} alt={card.player} />
                      <div className="player-details">
                        <h4>{card.player}</h4>
                        <span>{card.rank}</span>
                      </div>
                    </div>
                    <div className={`game-icon ${card.gameClass}`}>
                      {card.game}
                    </div>
                  </div>
                  
                  <div className="target-box">
                    <p>Hedef: <strong>{card.target}</strong></p>
                  </div>

                  <div className="card-footer">
                    <div className="bet-amount">
                      {card.bet} <span>Kredi</span>
                    </div>
                    <button className="accept-btn">Eşleşmeyi Kabul Et</button>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}
        
        {/* Diğer Menüler için Placeholder */}
        {activeMenu !== 'Lobi' && (
          <div style={{color: '#9ca3af', textAlign: 'center', marginTop: '5rem'}}>
            <h2>{activeMenu} Sayfası Yapım Aşamasında</h2>
          </div>
        )}

      </main>
    </div>
  );
};

export default Lobby;